
#kubectl delete namespace appmesh-demo

helm del --purge aws-appmesh-demo
helm del --purge aws-appmesh
kubectl delete crds \
    meshes.appmesh.k8s.aws \
    virtualnodes.appmesh.k8s.aws \
    virtualservices.appmesh.k8s.aws